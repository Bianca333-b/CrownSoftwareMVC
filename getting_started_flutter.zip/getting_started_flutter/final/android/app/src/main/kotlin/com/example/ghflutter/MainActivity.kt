package com.example.ghflutter

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
