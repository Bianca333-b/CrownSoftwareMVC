# GHFlutter

This app makes a network call to GitHub and displays a list of team member login names and avatar pictures.